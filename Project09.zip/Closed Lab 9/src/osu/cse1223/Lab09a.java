/*
 * Lab09a.java
 * 
 *   A program that asks the user for a list of numbers and stores them in an array. 
 *   Used to practice using arrays and breaking code up into methods, and as a first
 *   step to implementing Lab10b.java - selection sorting the final array.
 * 
 * @author Kelland Goodin 
 * @version 20181025
 * 
 */
package osu.cse1223;

import java.util.Scanner;

public class Lab09a {

	 

    public static void main(String[] args) {

               Scanner in = new Scanner(System.in);

               int b = getNumDigits(in);

               if (b==0) {

                          System.out.println("No digits to store? Goodbye!");

               }else {

               int[] digits = new int[b];

               getDigits(digits, in);

               displayDigits(digits);

               }

    }

   

    // Given a Scanner as input, prompts the user for the number of digits they will be

    // entering into an array.  If the number given by the user is less than 0, display

    // an error message and ask for a number that is 0 or greater.  When a valid number is

    // received, return it to the calling program.

    private static int getNumDigits(Scanner inScanner) {

               System.out.print("Enter the number of digits to be stored: ");

               int digit = inScanner.nextInt();

               while (digit<0) {

                          System.out.println("ERROR! You must enter a non-negative number of digits!");

                          System.out.println("");

                          System.out.print("Enter the length of the array: ");

                          digit = inScanner.nextInt();

               }

               return digit;

    }



    // Given an array and a Scanner as input, prompt the user to input integers to fill the

    // array.  The procedure should display a prompt for the user to enter an integer, and

    // should loop until the entire array is filled with integer.

    private static void getDigits(int[] digits, Scanner inScanner) {

               for(int i=0;i<digits.length;i++) {

                          System.out.print("Enter integer "+(i+1)+": ");

                          digits[i] = inScanner.nextInt();

               }

    }



   

    // Given an array as input, displays the total number of digits contained in the array

    // and displays the contents of the array in order, starting at index 0 and ending

    // with the final index of the array.

    private static void displayDigits(int[] digits) {

               System.out.println("The array has "+digits.length+" numbers in it");

               String str = "";

               for (int i=0;i<digits.length;i++) {

                          str = str+" "+digits[i];

               }

               System.out.println(str);

    }



    // FOR LAB10B

    // Given an array of integers as input, sorts the array using the Selection Sort algorithm

    // provided in the Closed Lab 10 write-up.

    private static void selectionSort(int[] digits) {



    }

   

}